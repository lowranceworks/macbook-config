Use babeljs.io to convert for IE11, but disable it in IE11 as Math.hypot is missing.
