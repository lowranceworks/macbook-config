# VS Code Kubernetes Tools Project Ownership

## Maintainers

The following people are current maintainers of the Kubernetes extension project:

* [Ivan Towlson](https://github.com/itowlson)
* [Luca Stocchi](https://github.com/lstocchi)
* [Bhargav Nookala](https://github.com/bnookala)
