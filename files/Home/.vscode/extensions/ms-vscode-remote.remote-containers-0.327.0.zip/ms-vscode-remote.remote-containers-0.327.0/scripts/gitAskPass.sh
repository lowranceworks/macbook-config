#!/bin/sh
echo "$GIT_TOKEN"