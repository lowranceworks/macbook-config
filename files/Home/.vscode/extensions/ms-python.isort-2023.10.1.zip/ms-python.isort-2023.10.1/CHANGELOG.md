# Changelog

**Please see https://github.com/microsoft/vscode-isort/releases for the latest release notes.**
