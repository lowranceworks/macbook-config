// @ts-check

"use strict";

module.exports = {
  "fileURLToPath": () => "",
  "pathToFileURL": () => ""
};
