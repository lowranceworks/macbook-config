# Json for Visual Studio Code

## Version 2.0.2 November 08, 2020

### New Features

- /

### Bug Fixes

- Fix repository url and readme.

---

## Version 2.0.1 September 05, 2020

### New Features

- /

### Bug Fixes

- Fix node.children is not iterable.

---

## Version 2.0.0 September 04, 2020

### New Features

- Add content count.
- Use TypeScript.

### Bug Fixes

- /

---

## Version 1.0.4 January 20, 2020

### New Features

- /

### Bug Fixes

- Fix sidebar icons.

---

## Version 1.0.1 February 28, 2019

### New Features

- Add menu node one-click folding function.

### Bug Fixes

- Solve the problem that vscode-json can't display.

---

## Version 1.0.0 February 28, 2019

### New Features

- Add json view

### Bug Fixes

- null



