<figure align="center">
  <img src="../../images/docs/side-bar-views.png" alt="All Open Sidebar Views" />
  <figcaption>GitLens Inspect as shown above has been manually moved into the Secondary Side Bar</figcaption>
</figure>
