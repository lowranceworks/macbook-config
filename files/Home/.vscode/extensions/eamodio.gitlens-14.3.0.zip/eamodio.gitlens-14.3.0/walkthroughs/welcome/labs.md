<figure align="center">
  <img src="gitkraken-labs.png" alt="GitKraken Labs" />
</figure>
