<figure align="center">
  <img src="../../images/docs/gutter-toggle.png" alt="Toggle File Annotations" />
  <figcaption>File Annotations</figcaption>
</figure>

<figure align="center">
  <img src="../../images/docs/gutter-blame.png" alt="File Blame" />
  <figcaption>File Blame</figcaption>
</figure>

<figure align="center">
  <img src="../../images/docs/gutter-changes.png" alt="File Changes" />
  <figcaption>File Changes</figcaption>
</figure>

<figure align="center">
  <img src="../../images/docs/gutter-heatmap.png" alt="File Heatmap" />
  <figcaption>Heatmap</figcaption>
</figure>
