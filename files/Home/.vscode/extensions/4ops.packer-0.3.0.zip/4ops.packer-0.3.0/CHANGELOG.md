# Change Log

## 0.3.0

- Added syntax highlighting for [packer](https://www.packer.io/docs/templates/hcl_templates/blocks/packer) block
- Added syntax highlighting for [datasources](https://www.packer.io/docs/datasources) blocks

## 0.2.0

- Added support for Packer variables files: `.pkrvars.hcl` ([#2](https://github.com/4ops/vscode-language-packer/issues/2))

## 0.1.1

- Update icon

## 0.1.0

- Initial release
