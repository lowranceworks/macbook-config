# Packer

This is a Visual Studio Code extension. Adds syntax support for the Packer HCL configuration language.

## Features

* Syntax highlighting
* Basic syntax validation
* No language server
* No telemetry
* No popups
* No credentials required
