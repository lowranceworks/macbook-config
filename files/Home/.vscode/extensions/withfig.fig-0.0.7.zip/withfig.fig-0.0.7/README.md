# Fig VS Code Extension

This extension is used to determine when the the VS Code integrated terminal has keyboard focus.

Please report any issues by emailing hello@withfig.com or running `fig report`
