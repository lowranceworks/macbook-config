# Go template support

Adds support for hightlighting 'text/template' and 'html/template'
Imported from GoSublime

Source code at: https://github.com/casualjim/vscode-gotemplate
