# Change Log

## [2021-11-08]

- First Release


## [2021-12-02]

- Alt syntax variant for Tokyo Night

## [2022-01-20]

- Approximately finished version.

## [2022-01-20]

- Fixed README.
