# Tokyo Night Themes

Dark themes based on Tokyo Night and Tokyo Storm palettes by Gogh

[Gogh project website](https://mayccoll.github.io/Gogh/)

---

## Screenshots

### Tokyo Night Gogh
![Tokyo Night](https://i.imgur.com/ZMb4ysH.png)

### Tokyo Storm Gogh
![Tokyo Storm](https://i.imgur.com/VeBRkaj.png)
