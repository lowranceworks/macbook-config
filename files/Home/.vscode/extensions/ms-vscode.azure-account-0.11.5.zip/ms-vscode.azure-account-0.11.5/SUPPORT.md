# Support

## How to file issues and get help

This project uses GitHub Issues to track bugs and feature requests. Please see https://aka.ms/azCodeIssueReporting for our issue reporting guidelines.

## Microsoft Support Policy

Support for this project is limited to the resources listed above.