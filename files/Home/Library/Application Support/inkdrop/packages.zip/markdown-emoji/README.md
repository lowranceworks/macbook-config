# inkdrop-markdown-emoji
Add gemoji (**G**itHub **Emoji**) syntax to Inkdrop markdown editor with all github supported emojies. 

## Supported Gemoji

See [gemoji's documentation](https://github.com/wooorm/gemoji/blob/master/support.md)

## Example

 * `:smile:` → 😄
 * `:yum:` → 😋

## Install

```
ipm install markdown-emoji
```

