# Tokyo Night syntax theme for Inkdrop

## Screenshot

![screenshot](https://raw.githubusercontent.com/dgavrilov/tokyo-night-syntax/master/screenshot.png)

## Installation

```sh
$ ipm install tokyo-night-syntax

# Additional
$ ipm install tokyo-night-dark-ui
```

## Related

* [dgavrilov/tokyo-night-dark-ui](https://github.com/dgavrilov/tokyo-night-dark-ui)

## License

This project is licensed under [MIT](LICENSE) license.
