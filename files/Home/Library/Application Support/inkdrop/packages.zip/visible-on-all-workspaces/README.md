Visible on All Workspaces
==============

Set the [Inkdrop](https://www.inkdrop.app/) window visible on all workspaces.

## Install

```sh
ipm install visible-on-all-workspaces
```

