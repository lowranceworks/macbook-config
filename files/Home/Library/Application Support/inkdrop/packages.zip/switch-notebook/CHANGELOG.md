## 0.1.0 - First Release
* Every feature added
* Every bug fixed

## 0.1.1
* Added "Switch notebook with return key" option.

## 0.2.0
* Updated to support Inkdrop `5.x`
