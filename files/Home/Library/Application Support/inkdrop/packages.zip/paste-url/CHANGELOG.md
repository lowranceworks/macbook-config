## 1.4.0 - Trim title whitespace
* trim whitespace in URL title - thanks to timblair for the PR
## 1.3.0 - Fix key bindings
* Fix key bindings so they show up in Plugin Settings
* Customize key bindings per-platform 
## 1.2.0 - Inkdrop 4.x support
* Migrated code to support Inkdrop 4.x
## 1.0.1 - First Release
* Fetches Title for first URL found on clipboard and pastes title and url as a markdown link
