# Tokyo Night Dark UI theme for Inkdrop

## Screenshot

![screenshot](https://raw.githubusercontent.com/dgavrilov/tokyo-night-dark-ui/master/screenshot.png)

## Installation

```sh
$ ipm install tokyo-night-dark-ui

# Additional
$ ipm install tokyo-night-syntax
```

## Related

* [dgavrilov/tokyo-night-syntax](https://github.com/dgavrilov/tokyo-night-syntax)

## License

This project is licensed under [MIT](LICENSE) license.
