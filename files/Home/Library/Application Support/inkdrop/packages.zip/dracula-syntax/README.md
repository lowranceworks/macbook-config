# inkdrop-dracula-syntax-theme
Dracula syntax theme for Inkdrop Markdown Editor
  
![Dracula Syntax](https://raw.githubusercontent.com/TaylanTatli/inkdrop-dracula-syntax-theme/master/preview.png)
  
[Dracula Theme](https://draculatheme.com)
